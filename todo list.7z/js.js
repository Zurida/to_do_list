// Add close button to exsisting tasks
var itemList = document.getElementsByTagName("li");

for (var i = 0; i <itemList.length; i++) {
  var span = document.createElement("span");
  var txt = document.createTextNode("\u00D7");
  span.className = "close";
  span.appendChild(txt);
  itemList[i].appendChild(span);
}

// Add new task
function addItem() {

	var newItem = document.createElement("li");
  var newText = document.getElementById("add-item").value;
  var textNode = document.createTextNode(newText);
  newItem.appendChild(textNode);

  if (newText === '') {
    alert("Не ленись, займись делами! А не то станешь салями!");
  } else {
    document.getElementById("menu").appendChild(newItem);
  }

// Add close button to new task
var span = document.createElement("span");
var txt = document.createTextNode("\u00D7");
span.className = "close";
span.appendChild(txt);
newItem.appendChild(span);

for (i = 0; i < close.length; i++) {
  close[i].onclick = function() {
    var div = this.parentElement;
    div.style.display = "none";
  }
}
}

// Hide clicked task
var close = document.getElementsByClassName("close");

for (i = 0; i < close.length; i++) {
  close[i].onclick = function() {
    var div = this.parentElement;
    div.style.display = "none";
  }
}

var btn = document.getElementById("add");
btn.addEventListener("click", addItem);


// Reward 

function getReward() {
  var rew = ["День спящего тюленя", "Поедание стейков", "Катание на теплоходе", "День просмотра сериалов", "Купание в фонтане", "Поездка на Бора-Бора"];

  var rand = Math.floor(Math.random() * rew.length);

  if (rand === 5) {document.getElementById("reward").innerHTML = "- НЕВЕРОЯТНО! Ты заработал супер приз: " + rew[rand] + "!";
} else {
  document.getElementById("reward").innerHTML = "- " + rew[rand];

}
}

var reward_btn = document.getElementById("show-reward");
reward_btn.addEventListener("click", getReward);

